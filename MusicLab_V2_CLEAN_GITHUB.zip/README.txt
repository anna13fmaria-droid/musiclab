MUSIC LAB V2 — ЧИСТАЯ ВЕРСИЯ

ПРОВЕРКА НА КОМПЬЮТЕРЕ
1. Полностью распакуйте ZIP-архив.
2. Откройте распакованную папку.
3. Дважды нажмите index.html.
4. Не открывайте index.html прямо внутри WinRAR.

ЗАГРУЗКА НА GITHUB
Загрузите содержимое этой папки в корень репозитория:
index.html, nobilis.html, css, js, images, .nojekyll

После загрузки:
Settings → Pages → Deploy from a branch → main → /(root) → Save

Адрес сайта:
https://anna13fmaria-droid.github.io/musiclab/

Страница Nobilis:
https://anna13fmaria-droid.github.io/musiclab/nobilis.html
